/*Maps current topic to its parent: "topicIndex:parentIndex". -1 represents the map.*/
define(function () {
return {1:0,2:0,0:-1,17:-1,5:14,18:-1,19:14,16:14,6:14,15:14};
});